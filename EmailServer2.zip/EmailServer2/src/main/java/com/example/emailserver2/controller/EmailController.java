package com.example.emailserver2.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.emailserver2.entity.Email;
import com.example.emailserver2.mapper.EmailMapper;
import com.example.emailserver2.runner.PostServer;
import com.example.emailserver2.service.EmaiService;
import com.example.emailserver2.service.serviceImpl.EmailServiceImpl;
import com.example.emailserver2.utils.ResultUtils;
import com.example.emailserver2.utils.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RequestMapping("")
@RestController
public class EmailController {

  @Autowired
  EmailServiceImpl emailService;

  @Autowired
  EmailMapper emailMapper;

  /**
   * 获取邮件列表
   * @param username 用户名
   * @return 邮件列表
   */
  @ResponseBody
  @GetMapping("/getEmailList")
  public ResultVo getEmailList (@RequestParam("username") String username) {
    // 将username作为收件人进行查看
    QueryWrapper<Email> queryWrapper = Wrappers.query();
    queryWrapper.eq("toUser",username);
    List<Email> list = emailService.list(queryWrapper);
    return ResultUtils.success("获取邮件成功", list);
  }

  /**
   * 获取指定邮件
   * @param username 用户名 eId 邮件id
   * @return 指定邮件内容
   */
  @ResponseBody
  @GetMapping("/getEmail")
  public ResultVo getEmail (@RequestParam("username") String username, @RequestParam("eId") String eId) {
    // 查看指定用户的指定邮件
    QueryWrapper<Email> queryWrapper = Wrappers.query();
    queryWrapper.eq("eId",eId).eq("toUser",username).or().eq("fromUser",username);
    Email email = emailService.getOne(queryWrapper);
    if (email != null) {
      return ResultUtils.success("获取id为" + email.getEId() + "邮件成功", email);
    }
    else return ResultUtils.error("未查询到指定邮件!");
  }

  /**
   * 发送邮件
   * @param hashMap 包含 发件人 收件人 主题 内容
   * @return 发送结果
   */
  @ResponseBody
  @PostMapping("/sendEmail")
  public ResultVo sendEmail (@RequestBody HashMap<String, String> hashMap) {
    return PostServer.postEmail(hashMap);
  }

  /**
   * 发送邮件
   * @param hashMap 指定邮件id
   * @return 删除结果
   */
  @ResponseBody
  @PostMapping("/deleteEmail")
  public ResultVo deleteEmail (@RequestBody HashMap<String, String> hashMap) {
    String preEid = hashMap.get("eId");
    int eid = Integer.parseInt(preEid);
    QueryWrapper<Email> queryWrapper = Wrappers.query();
    queryWrapper.eq("eId",eid);
    emailService.remove(queryWrapper);
    return ResultUtils.success("删除邮件成功");
  }
}
