package com.example.emailserver2.service.serviceImpl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.emailserver2.entity.Email;
import com.example.emailserver2.mapper.EmailMapper;
import com.example.emailserver2.service.EmaiService;
import org.springframework.stereotype.Service;

@Service
public class EmailServiceImpl extends ServiceImpl<EmailMapper, Email> implements EmaiService {
}
