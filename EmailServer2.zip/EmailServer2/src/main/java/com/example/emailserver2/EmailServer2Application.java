package com.example.emailserver2;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.example.emailserver2.mapper")
@EnableScheduling
public class EmailServer2Application {

  public static void main(String[] args) {
    SpringApplication.run(EmailServer2Application.class, args);
  }

}
