package com.example.emailserver2.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.sql.Timestamp;

@Data
public class Email {
  @TableId(value = "eId", type = IdType.AUTO)
  private String eId;
  @TableField(value = "fromUser")
  private String fromUser;
  @TableField(value = "toUser")
  private String toUser;
  private String title;
  private String content;
  @TableField(value = "recvTime")
  private String recvTime;
}
