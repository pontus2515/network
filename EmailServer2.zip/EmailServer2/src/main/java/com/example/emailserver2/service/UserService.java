package com.example.emailserver2.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.emailserver2.entity.User;

public interface UserService extends IService<User> {
}
