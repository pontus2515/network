package com.example.emailserver2.runner;


import com.example.emailserver2.utils.ResultUtils;
import com.example.emailserver2.utils.ResultVo;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

/**
 * 使用PostServer通过SMTP连接发送邮件
 */
public class PostServer {
  public static ResultVo postEmail(HashMap<String, String> hashMap) {
    try {
      // 建立与邮件服务器的连接
      String ip = "10.147.17.90";
      int port = 25; // SMTP协议使用25号端口
      System.out.println("正在与邮件服务器建立SMTP协议连接");
      Socket socket = new Socket(ip, port);
      System.out.println("已成功连接到远程主机" + socket.getInetAddress());
      OutputStream outputStream = socket.getOutputStream();
      PrintWriter printWriter = new PrintWriter(outputStream);
      String from = hashMap.get("from");
      String to = hashMap.get("to");
      String title = hashMap.get("title");
      String content = hashMap.get("content");
      // 内容为空则返回错误
      if (from == null || to == null || title == null || content == null) {
        return  ResultUtils.error("邮件内容不全，请编辑后重试！");
      }
      // 考虑将 %2A 作为分割符，方便邮件内容的切割
      printWriter.write(from + "%2A"  + to + "%2A" + title + "%2A" + content + "$7L");
      printWriter.flush();
      socket.close();
      return ResultUtils.success("邮件发送成功！");
    } catch (Exception exception) {
      return ResultUtils.error("网络繁忙，请稍后重试");
    }
  }
}
