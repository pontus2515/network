package com.example.emailserver2.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.emailserver2.entity.Email;

public interface EmaiService extends IService<Email> {
}
