package com.example.emailserver2.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
public class User {
  @TableId(value = "uid", type = IdType.AUTO)
  private String uid;
  private String username;
  private String password;
  private String phone;
  @TableField(value = "isAdmin")
  private String isAdmin;
}
