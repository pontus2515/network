package com.example.emailserver2.controller;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.emailserver2.entity.User;
import com.example.emailserver2.mapper.UserMapper;
import com.example.emailserver2.service.serviceImpl.UserServiceImpl;
import com.example.emailserver2.utils.ResultUtils;
import com.example.emailserver2.utils.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("")
public class UserController {
  @Autowired
  private UserServiceImpl userService;

  @Autowired
  private UserMapper userMapper;

  /**
   * 登录
   * @param hashMap 用户名 密码
   * @return 登录结果和是否为管理员
   */
  @PostMapping("/login")
  @ResponseBody
  public ResultVo login (@RequestBody HashMap<String, String> hashMap) {
    String username = hashMap.get("username");
    String password = hashMap.get("password");
    // 在用户列表中查找对象并验证密码
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username", username);
    User user = userService.getOne(queryWrapper);
    if(user == null) {
      return ResultUtils.error("账号或密码错误");
    }
    if (user.getPassword().equals(password)) {
      // 返回用户是否为管理员和手机号码
      HashMap<String, String> stringHashMap = new HashMap<>();
      stringHashMap.put("isAdmin",user.getIsAdmin());
      stringHashMap.put("phone",user.getPhone());
      return ResultUtils.success("登陆成功",stringHashMap);
    } else {
      return ResultUtils.error("账号或密码错误");
    }
  }

  /**
   * 注册
   * @param hashMap 用户名 密码 手机号
   * @return 注册结果和是否为管理员
   */
  @PostMapping("/register")
  @ResponseBody
  public ResultVo register (@RequestBody HashMap<String, String> hashMap) {
    String username = hashMap.get("username");
    String password = hashMap.get("password");
    String phone = hashMap.get("phone");
    // 查看用户名是否已被占用
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username", username);
    User user = userService.getOne(queryWrapper);
    if(user != null) {
      return ResultUtils.error("用户名已被占用");
    }
    user = new User();
    user.setIsAdmin("no");
    user.setUsername(username);
    user.setPassword(password);
    user.setPhone(phone);
    userMapper.insert(user);
    HashMap<String, String> stringHashMap = new HashMap<>();
    stringHashMap.put("isAdmin",user.getIsAdmin());
    stringHashMap.put("phone",user.getPhone());
    return ResultUtils.success("注册成功",stringHashMap);
  }

  /**
   * 获取个人信息
   * @param  username 用户名
   * @return 个人信息 username phone
   */
  @GetMapping("/getPersonInfo")
  @ResponseBody
  public ResultVo getPersonInfo (@RequestParam("username")String username) {
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username", username);
    User user = userService.getOne(queryWrapper);
    if(user == null) {
      return ResultUtils.error("未找到此用户");
    }
    HashMap<String, String> stringHashMap = new HashMap<>();
    stringHashMap.put("username",user.getUsername());
    stringHashMap.put("phone",user.getPhone());
    return ResultUtils.success("成功获取到个人信息",stringHashMap);
  }

  /**
   * 修改用户信息
   * @param hashMap 用户名 密码 手机号
   * @return 修改结果
   */
  @ResponseBody
  @PostMapping("/updateInfo")
  public ResultVo updateInfo (@RequestBody HashMap<String, String> hashMap) {
    String username = hashMap.get("username");
    String password = hashMap.get("password");
    String phone = hashMap.get("phone");
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username", username);
    User user = userService.getOne(queryWrapper);
    if(user == null) {
      return ResultUtils.error("未找到此用户");
    }
    user.setPassword(password);
    user.setPhone(phone);
    userService.updateById(user);
    return ResultUtils.success("修改用户" + username + "信息成功");
  }

  /**
   * 获取用户列表
   * @param username 用户名
   * @return 用户列表
   */
  @ResponseBody
  @GetMapping("/getUserList")
  public ResultVo getUserList (@RequestParam("username") String username) {
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username",username);
    User user = userService.getOne(queryWrapper);
    if (user == null) {
      return ResultUtils.error("未找到此用户");
    }
    if (user.getIsAdmin().equals("yes")) {
      List<User> list = userMapper.selectList(null);
      return ResultUtils.success("获取用户列表成功", list);
    } else {
      return ResultUtils.error("该用户没有权限！");
    }
  }

  /**
   * 返回用户日志
   * @param username 用户名
   * @return 查看日志结果
   */
  @ResponseBody
  @GetMapping("/getLogList")
  public ResultVo getLogList (@RequestParam("username") String username) {
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username",username);
    User user = userService.getOne(queryWrapper);
    if (user == null) {
      return ResultUtils.error("未找到此用户");
    }
    if (user.getIsAdmin().equals("yes")) {
      return ResultUtils.success("查询成功！");
    } else {
      return ResultUtils.error("该用户没有权限！");
    }
  }

  /**
   * 删除用户
   * @param hashMap 用户名
   * @return 删除结果
   */
  @ResponseBody
  @PostMapping("/deleteUser")
  public ResultVo deleteUser (@RequestBody HashMap<String, String> hashMap) {
    String username = hashMap.get("username");
    QueryWrapper<User> queryWrapper = Wrappers.query();
    queryWrapper.eq("username",username);
    userService.remove(queryWrapper);
    return ResultUtils.success("删除用户：" + username + "成功！");
  }
}
