package com.example.emailserver2.runner;


import com.example.emailserver2.entity.Email;
import com.example.emailserver2.mapper.EmailMapper;
import com.example.emailserver2.service.serviceImpl.EmailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.xml.crypto.Data;
import java.io.InputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 使用GetServer通过POP3进行对邮件服务器邮件的拉取
 */
@Component
public class GetServer {
  @Autowired
  EmailServiceImpl emailService;

  @Autowired
  EmailMapper emailMapper;

  /**
   * 每隔一点时间从邮件服务器拉取邮件并加入数据库
   */
  @Scheduled(cron = "*/3 * * * * ?")
  public void getEmail () throws Exception {
    System.out.println("正在与邮件服务器建立POP3协议连接");
    // 建立与邮件服务器的连接
    String ip = "10.147.17.90";
    int port = 110; // POP3协议使用110端口
    Socket socket = new Socket(ip, port);
    InputStream inputStream = socket.getInputStream();
    byte[] bytes = new byte[1024];
    int len;
    StringBuilder sb = new StringBuilder();
    while ((len = inputStream.read(bytes)) != -1) {
      sb.append(new String(bytes, 0, len, "UTF-8"));
    }
    String emails = sb.toString();
    System.out.println("收到邮件列表内容为：" + '\n' + emails);
    // 及时关闭socket连接
    socket.close();
    // 首先检查邮件服务器有没有传过来邮件
    if (emails.equals("$$Sorry...Nothing here$$")) {
      return;
    }
    // 首先将每个邮件分割开来，然后再对单个邮件进行提取
    List<String> stringList = new ArrayList<>(); // 存分割开来的邮件
    while (true) {
      int index = emails.indexOf("$7L");
      if (index < 0) {
        break;
      }
      String emailElement = emails.substring(0, index); // 真实的一个邮件
      emails = emails.substring(index + 3); // 剔除已经获取的邮件
      stringList.add(emailElement);
      System.out.println("分离出邮件：" + emailElement);
    }
    // 此时已经获取到实际意义上的邮件列表，但是我们需要针对 from to title content 进行提取
    for (String emailElement : stringList) {
      Email email = new Email(); // 此处的Email为一个entity 而emailElement为列表里的一个元素
      // 提取from
      int index = emailElement.indexOf("%2A");
      String from = emailElement.substring(0, index);
      emailElement = emailElement.substring(index + 3);
      // 提取to
      index = emailElement.indexOf("%2A");
      String to = emailElement.substring(0, index);
      emailElement = emailElement.substring(index + 3);
      // 提取title
      index = emailElement.indexOf("%2A");
      String title = emailElement.substring(0, index);
      emailElement = emailElement.substring(index + 3);
      // 提取content
      String content = emailElement;
      // 创建邮件实体
      email.setFromUser(from);
      email.setToUser(to);
      email.setTitle(title);
      email.setContent(content);
      SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      String date = df.format(new Date());// new Date()
      email.setRecvTime(date);
      System.out.println("即将保存以下邮件到数据库：" + email);
      // 将实体加入到数据库
      emailMapper.insert(email);
      System.out.println("保存成功！");
    }
  }
}