package servers;

import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * 邮件服务器发送端
 * 获取待发送的邮件列表，然后进行发送
 */
public class PostServer {
  public static void sendEmail(List<String> list) throws Exception {
    // 日后可以根据报文决定发送至的邮件服务器
	String ip = "10.147.17.90";
    int port = 25;
    // 连接至指定的邮件服务器进行发送
    Socket socket = new Socket(ip, port);
    System.out.println("成功连接到邮件服务器：" + socket.getInetAddress());
    System.out.println("邮件发送端SMTP已启动");
    OutputStream outputStream = socket.getOutputStream();
    PrintWriter printWriter = new PrintWriter(outputStream);
    for (String string : list) {
      printWriter.write(string + "$7L");
    }
    printWriter.flush();
    socket.close();
  }
}