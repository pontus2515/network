package servers;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * 邮件服务器接收端
 * 1.首先等待邮件服务器发送端的连接
 * 2.将邮件服务器发送端发送的邮件保存在邮箱中
 * 3.等待代理端以110的pop3协议进行访问
 * 4.代理端连接后邮件服务器将邮件全部输出至代理服务器
 * 5.规定报文中 from to title content, 邮件中不能出现$7L字符
 * 6.多邮件传输时以$7L进行分割
 */
public class GetServer {
  // 用户邮箱
  private static List<String> list = new ArrayList<>();

  // 发送队列
  private static LinkedBlockingDeque<String> blockingDeque = new LinkedBlockingDeque<>(100);

  public static void main(String args[]) throws Exception {
    // 监听指定的端口
    // 监听来自邮件服务器邮件的端口
    int SMTPport = 25;
    // 监听来自代理服务器邮件的端口
    int POP3port = 110;
    ServerSocket SMTPserver = new ServerSocket(SMTPport);
    ServerSocket POP3server = new ServerSocket(POP3port);
    // server将一直等待连接的到来
    System.out.println("正在等待远程主机的连接...");

      POP3thread pop3thread = new POP3thread(POP3server);
      SMTPthread smtPthread = new SMTPthread(SMTPserver);
      Sendthread sendthread = new Sendthread();
      pop3thread.start();
      smtPthread.start();
      sendthread.start();

  }

  /**
   * 用于检测队列是否为空，若非空则发送，若为空则阻塞
   */
  public static class Sendthread extends Thread {
    public void run () {
      while (true) {
        System.out.println("邮件接收端POP3已启动");
        System.out.println("邮件发送端已启动..." + "此时发送队列大小为:" + blockingDeque.size());
        System.out.println("邮件发送端已启动..." + "此时邮箱大小为:" + list.size());
        try {
          if (blockingDeque.isEmpty()) {
            sleep(3000);
          } else {
            List<String> stringList = new ArrayList<>();
            while (!blockingDeque.isEmpty()) {
              stringList.add(blockingDeque.pollFirst());
            }
            PostServer.sendEmail(stringList);
          }
        } catch (Exception exception) {
          exception.printStackTrace();
        }
      }
    }
  }
  
  /**
   * 用于连接代理端pop3协议的线程
   * pop3协议中，用户拉取邮箱邮件后服务器不再保留邮件
   */
  public static class POP3thread extends Thread {
    public ServerSocket serverSocket;
    public POP3thread (ServerSocket serverSocket) {
      this.serverSocket = serverSocket;
    }

    /**
     * 将服务器邮件内容全部发送给代理服务器，然后清空邮箱
     * @param socket 套接字
     */
    private void getFromGuest (Socket socket) {
      try {
        System.out.println("成功连接到代理服务器" + socket.getInetAddress());
        // 注意这里传输的为一个List对象
        OutputStream outputStream = socket.getOutputStream();
        PrintWriter printWriter = new PrintWriter(outputStream);
        if (list.isEmpty()) { // 注意当邮箱为空时不返回邮件
          printWriter.write("$$Sorry...Nothing here$$");
          printWriter.flush();
          socket.close();
          return;
        }
        System.out.println("邮件接收端POP3已启动");
        System.out.println("代理正在拉取邮件..." + "此时发送队列大小为:" + blockingDeque.size());
        System.out.println("代理正在拉取邮件..." + "此时邮箱大小为:" + list.size());
        for (String s : list) {
          printWriter.write(s + "$7L");
        }
        list.clear();
        printWriter.flush();
        socket.close();
      } catch (Exception exception) {
        exception.printStackTrace();
      }
    }

    /**
     * 如果连接来自邮件服务器则接收邮件，若来自代理服务器则输出邮箱中的邮件并清空邮件
     */
    public void run () {
      while (true) {
        String email = new String();
        try {
          Socket socket = serverSocket.accept();
          System.out.println("已远程连接到主机： " + socket.getInetAddress());
          System.out.println("本机地址为：" + socket.getLocalAddress());
          getFromGuest(socket);
        } catch (Exception exception) {
          exception.printStackTrace();
        }
      }
    }
  }

  /**
   * 用于连接代理端SMTP协议的线程
   * 1.代理服务器发送待发送邮件，此时将邮件存入队列
   * 2.收到邮件服务器发来的邮件，此时将邮件存入邮箱
   */
  public static class SMTPthread extends Thread {
    public ServerSocket serverSocket;
    public SMTPthread (ServerSocket serverSocket) {
      this.serverSocket = serverSocket;
    }

    /**
     * 获取邮件服务器的邮件
     * @param socket 套接字
     */
    private void getFromHost (Socket socket) {
      try {
        System.out.println("成功连接到邮件服务器" + socket.getInetAddress());
        System.out.println("邮件接收端SMTP已启动");
        InputStream inputStream = socket.getInputStream();
        byte[] bytes = new byte[1024];
        int len;
        StringBuilder sb = new StringBuilder();
        while ((len = inputStream.read(bytes)) != -1) {
          // 注意指定编码格式，发送方和接收方一定要统一，建议使用UTF-8
          sb.append(new String(bytes, 0, len, "UTF-8"));
        }
        // 输出邮件内容进行查看
        String email = sb.toString();
        // 判断连接的ip为邮件服务器还是代理服务器
        String connectIP = String.valueOf(socket.getInetAddress());
        String serverIP = String.valueOf(socket.getLocalAddress()); // 此处日后可以为一个列表，存储邮件服务器的ip地址
        if (connectIP.equals(serverIP)) {
          // 此时表明为邮件服务器
          System.out.println("收到来自邮件服务器的邮件：" + "\n" + email);
          // 将邮件服务器发送的邮件列表进行转换
          List<String> arriveList = new ArrayList<>();
          while (true) {
            int index = email.indexOf("$7L");
            if (index < 0) {
              break;
            }
            String emailElement = email.substring(0, index); // 真实的一个邮件
            email = email.substring(index + 3); // 剔除已经获取的邮件
            list.add(emailElement);
            System.out.println("分离出邮件：" + emailElement);
          }
        } else {
          // 此时表明为代理服务器
          System.out.println("收到来自代理服务器的邮件：" + "\n" + email);
          // 将代理服务器发送的邮件列表进行转换
          List<String> arriveList = new ArrayList<>();
          while (true) {
            int index = email.indexOf("$7L");
            if (index < 0) {
              break;
            }
            String emailElement = email.substring(0, index); // 真实的一个邮件
            email = email.substring(index + 3); // 剔除已经获取的邮件
            blockingDeque.add(emailElement);
            System.out.println("分离出邮件：" + emailElement);
          }
        }
        socket.close();
      } catch (Exception exception) {
        exception.printStackTrace();
      }
    }

    /**
     * 如果连接来自邮件服务器则接收邮件，若来自代理服务器则输出邮箱中的邮件并清空邮件
     */
    public void run () {
      while (true) {
        String email = new String();
        try {
          System.out.println("邮件接收端SMTP已启动");
          Socket socket = serverSocket.accept();
          System.out.println("已远程连接到主机： " + socket.getInetAddress());
          System.out.println("当前本机的地址为：" + socket.getLocalAddress());
          // 判断该连接来自服务器还是代理服务器
          getFromHost(socket);
        } catch (Exception exception) {
          exception.printStackTrace();
        }
      }
    }
  }
}
